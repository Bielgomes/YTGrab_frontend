export const defaultTheme = {
  white: '#FFFFFF',

  'red-500': '#EF4444',

  'zinc-900': '#18181B',
  'zinc-800': '#27272A',
  'zinc-700': '#3F3F46',

  'blue-400': '#22D3EE',

  'green-400': '#4ADE80',
}
